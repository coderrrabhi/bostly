import type { Rng, ShapeRun } from "./runShaping";

/**
 * Views-linked engagement runs (likes, saves, shares, reposts — not comments).
 * Every engagement run is sized from the Views run it follows: it carries the
 * order's engagement % of that Views run (bundle ratio), so bigger Views runs
 * get bigger engagement runs and the selected curve is followed exactly.
 * Units below the per-run minimum carry to the next Views run. Rounding left
 * over at the end goes only to the curve's peak runs (largest Views runs), a
 * small share per run, so there is never a spike and no add-on on every run.
 */
const t = (r: ShapeRun) => Date.parse(r.scheduled_at);
const sortByTime = <T extends ShapeRun>(runs: T[]) => [...runs].sort((a, b) => t(a) - t(b));

export const isLinkedEngagement = (type: string) => !/views?$/i.test(type) && !/comment/i.test(type);

export function linkRunsToViews<T extends ShapeRun>(opts: {
  views: ShapeRun[]; template: T; total: number; min: number; max: number; rng?: Rng;
}): T[] | null {
  const rng = opts.rng ?? Math.random;
  const views = sortByTime(opts.views).filter((r) => r.quantity_to_send > 0);
  const viewsTotal = views.reduce((a, r) => a + r.quantity_to_send, 0);
  const total = Math.floor(opts.total);
  const min = Math.max(1, Math.floor(opts.min));
  const max = Math.max(0, Math.floor(opts.max));
  if (!views.length || !(viewsTotal > 0) || total < min) return null;
  const ratio = total / viewsTotal;

  const out: Array<{ idx: number; q: number }> = [];
  let acc = 0;
  let sent = 0;
  for (let i = 0; i < views.length; i += 1) {
    acc += ratio * views[i].quantity_to_send * (0.94 + rng() * 0.12);
    if (acc < min) continue;
    let q = Math.floor(acc);
    if (max > 0) q = Math.min(q, max);
    if (q < min) continue;
    out.push({ idx: i, q });
    sent += q;
    acc -= q;
  }
  if (!out.length) {
    const peak = views.reduce((b, r, i) => (r.quantity_to_send > views[b].quantity_to_send ? i : b), 0);
    out.push({ idx: peak, q: total });
    sent = total;
  }

  // Remainder (+ or -) goes to the peak runs only, ~12% of a run at most per pass.
  let diff = total - sent;
  const peaks = [...out.keys()].sort((a, b) => views[out[b].idx].quantity_to_send - views[out[a].idx].quantity_to_send);
  // Each run moves at most ~20% of its own size, one unit per step, peaks first.
  const moved = out.map(() => 0);
  for (let pass = 0; diff !== 0 && pass < 10000; pass += 1) {
    let changed = false;
    for (const k of peaks) {
      if (diff === 0) break;
      const cap = Math.max(1, Math.round(out[k].q * 0.2));
      if (Math.abs(moved[k]) >= cap) continue;
      if (diff > 0 && (max <= 0 || out[k].q < max)) { out[k].q += 1; moved[k] += 1; diff -= 1; changed = true; }
      else if (diff < 0 && out[k].q - 1 >= min) { out[k].q -= 1; moved[k] -= 1; diff += 1; changed = true; }
      if (pass % 3 !== 2) break; // favour the biggest peaks, then widen
    }
    if (!changed && pass % 3 === 2) break;
  }
  if (diff !== 0) return null;

  // Two back-to-back runs never carry the same quantity (move 1 to/from a peak).
  const gave = new Set<number>();
  for (let i = 1; i < out.length; i += 1) {
    if (out[i].q !== out[i - 1].q) continue;
    const donor = peaks.find((k) => !gave.has(k) && Math.abs(k - i) > 1 && out[k].q - 1 >= min && out[k].q >= 4
      && out[k].q - 1 !== out[k - 1]?.q && out[k].q - 1 !== out[k + 1]?.q);
    if (donor !== undefined && (max <= 0 || out[i].q + 1 <= max)) { out[i].q += 1; out[donor].q -= 1; gave.add(donor); }
  }

  // Each run goes out 1-6 minutes after its Views run (never at or past the next Views run).
  let prev = -Infinity;
  return out.map(({ idx, q }) => {
    const at = t(views[idx]);
    const next = idx + 1 < views.length ? t(views[idx + 1]) : at + 10 * 60_000;
    const room = Math.max(60_000, Math.min(6 * 60_000, next - at - 60_000));
    let when = at + 60_000 + Math.floor(rng() * Math.max(1, room - 60_000));
    if (when <= prev) when = prev + 60_000;
    prev = when;
    return { ...opts.template, scheduled_at: new Date(when).toISOString(), quantity_to_send: q, base_quantity: q, variance_applied: 0, peak_multiplier: 1 };
  });
}

/**
 * Removes unusual Views spikes/dips: a run may differ at most ~15% from the
 * average of its neighbours. Moved units are spread back along the curve in
 * proportion to run size, so the total stays exact and the shape stays natural.
 * The first two runs (small start) are left untouched.
 */
export function smoothViewsSpikes<T extends ShapeRun>(runs: T[], min: number, max: number): T[] {
  const list = sortByTime(runs).map((r) => ({ ...r }));
  const n = list.length;
  if (n < 5) return list;
  const q = list.map((r) => r.quantity_to_send);
  const total = q.reduce((a, b) => a + b, 0);
  for (let i = 2; i < n - 1; i += 1) {
    const base = (q[i - 1] + q[i + 1]) / 2;
    q[i] = Math.round(Math.min(base * 1.15, Math.max(base * 0.85, q[i])));
  }
  let diff = total - q.reduce((a, b) => a + b, 0);
  const body = q.slice(2).reduce((a, b) => a + b, 0) || 1;
  for (let i = 2; i < n && diff !== 0; i += 1) {
    const share = Math.trunc((diff * q[i]) / body);
    q[i] += share;
  }
  diff = total - q.reduce((a, b) => a + b, 0);
  const order = [...q.keys()].slice(2).sort((a, b) => q[b] - q[a]);
  for (let k = 0; diff !== 0 && k < order.length * 4; k += 1) {
    const i = order[k % order.length];
    const step = diff > 0 ? 1 : -1;
    if (q[i] + step >= min && (max <= 0 || q[i] + step <= max)) { q[i] += step; diff -= step; }
  }
  if (diff !== 0 || q.some((x) => x < min || (max > 0 && x > max))) return list;
  for (let i = 1; i < n; i += 1) {
    if (q[i] === q[i - 1] && i + 1 < n && q[i + 1] - 1 !== q[i] + 1 && q[i + 1] - 1 >= min) { q[i] += 1; q[i + 1] -= 1; }
  }
  return list.map((r, i) => ({ ...r, quantity_to_send: q[i], base_quantity: q[i] }));
}
